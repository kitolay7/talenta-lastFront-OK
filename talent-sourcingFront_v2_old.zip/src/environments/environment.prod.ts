export const environment = {
  production: true,
  /*   baseUrl: 'http://localhost:8181/' */
  //baseUrl: 'https://talenta-sourcing-back.herokuapp.com/'
  //baseUrl: 'https://ws.talenta-sourcing.com/'
  baseUrl: 'https://back.talenta.mg/'
};
