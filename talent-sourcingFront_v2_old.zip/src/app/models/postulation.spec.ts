import { Postulation } from './postulation';

describe('Postulation', () => {
  it('should create an instance', () => {
    expect(new Postulation()).toBeTruthy();
  });
});
