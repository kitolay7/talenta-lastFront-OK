export class Video {
    id: number;
    question: string;
    reponse: number;
    duree: number;
    point: number;
}
