import { Component } from '@angular/core';

@Component({
  selector: 'app-header-admin-auth',
  templateUrl: './header-admin-auth.component.html',
  styleUrls: ['./header-admin-auth.component.scss']
})
export class HeaderAdminAuthComponent {}
