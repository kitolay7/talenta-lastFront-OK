import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-form-recruteur',
  templateUrl: './profile-form-recruteur.component.html',
  styleUrls: ['./profile-form-recruteur.component.scss']
})
export class ProfileFormRecruteurComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
