import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { from } from 'rxjs';
import { OffreService } from '../../services/offre.service';
import { PostulationService } from '../../services/postulation.service';
import { ActivatedRoute } from '@angular/router';
import { Socket } from 'ngx-socket-io';
import { CvService } from '../../../../src/app/services/cv.service';

@Component({
	selector: 'app-gestion-candidats',
	templateUrl: './gestion-candidats.component.html',
	styleUrls: ['./gestion-candidats.component.scss'],
})
export class GestionCandidatsComponent implements OnInit {

	constructor(
		private socket: Socket,
		private offreS: OffreService,
		private postulationS: PostulationService,
		private route: ActivatedRoute,
		private cvService: CvService
	) { }

	ngOnInit(): void {

		this.offreS.geteOfferUser(localStorage.getItem('idUser')).subscribe((res: any) => {
			//console.log(res)
			this.offres = res;
			this.offres.forEach(offre => {
				this.offreS.getUsersByOffer(offre.id).subscribe(response => {
					this.postulations = response.data;
					//console.log(this.postulations);
					if (this.postulations.length > 0) {
						this.allCandidats.push(this.postulations[0]);
					}
				})
			})
			this.loading = true;
		})
	}
	title = "LA GESTION DES CANDIDATURES";
	postulations = [];
	allC = [];
	allCandidats = [];
	offres: any;
	candidats: any[] = [];
	loading = false;

	// === NOUVEAU : critères de tri GPT ===
	diplomeCritere: string = '';
	experienceMinCritere: number = 0;
	fonctionsCritere: string = '';
	customPrompt: string = '';
	gptResult: any = null;
	filtering = false;
	// =====================================


	getDecision(totalPoint: number, note: number) {
		if (totalPoint === 0) {
			return "En attente";
		}
		if (note < (totalPoint / 2)) {
			return "Refusé";
		}
		else {
			return "Entretien";
		}
	}

	// === NOUVEAU : appel GPT pour filtrer les CV ===
	filtrerCvsAvecGpt() {
		this.filtering = true;
		const fonctions = this.fonctionsCritere
		? this.fonctionsCritere.split(',').map(f => f.trim()).filter(f => !!f)
		: [];

		const criteria = {
		diplome: this.diplomeCritere,
		experienceMin: this.experienceMinCritere,
		fonctions,
		customPrompt: this.customPrompt
		};

		const cvs = this.candidats.map(c => ({
		id: c.user.id,
		nom: c.user.profile.firstName + ' ' + c.user.profile.lastName,
		diplome: c.user.profile.diplomes,
		experience: c.user.profile.anneesExperiences,
		fonction: c.user.profile.metierActuel,
		// si besoin, on peut également envoyer une URL vers le CV
		cvUrl: c.user.profile.cvPath ? (/* baseUrl côté front */ '/cv/' + c.user.profile.cvPath) : null
		}));

		this.cvService.filterCvs(criteria, cvs).subscribe(res => {
		this.gptResult = res.filteredCvs;
		this.filtering = false;
		}, err => {
		console.error(err);
		this.filtering = false;
		});
	}
	// =====================================

}
