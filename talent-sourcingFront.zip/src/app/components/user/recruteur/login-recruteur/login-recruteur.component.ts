import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-recruteur',
  templateUrl: './login-recruteur.component.html',
  styleUrls: ['./login-recruteur.component.scss']
})
export class LoginRecruteurComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
