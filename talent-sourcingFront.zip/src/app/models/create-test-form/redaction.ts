export class Redaction {
    id: number;
    question: string;
    reponse: number;
    duree: number;
    point: number;
}
