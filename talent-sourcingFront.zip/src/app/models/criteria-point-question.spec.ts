import { CriteriaPointQuestion } from './criteria-point-question';

describe('CriteriaPointQuestion', () => {
  it('should create an instance', () => {
    expect(new CriteriaPointQuestion()).toBeTruthy();
  });
});
