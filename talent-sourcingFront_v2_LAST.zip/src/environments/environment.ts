// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  //baseUrl: 'http://154.126.92.194:8181/'
  //baseUrl: 'https://back.talenta.mg/'	
  //baseUrl: 'https://talenta-sourcing-back.herokuapp.com/'
  //baseUrlAdmin: 'http://localhost:4200'
  baseUrl: 'http://localhost:8181/',
  //baseUrl: 'http://51.255.51.189:8181/'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
