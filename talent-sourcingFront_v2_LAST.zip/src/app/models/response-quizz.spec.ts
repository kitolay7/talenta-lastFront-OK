import { ResponseQuizz } from './response-quizz';

describe('ResponseQuizz', () => {
  it('should create an instance', () => {
    expect(new ResponseQuizz()).toBeTruthy();
  });
});
