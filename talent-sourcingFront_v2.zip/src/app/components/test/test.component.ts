import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { OffreService } from 'src/app/services/offre.service';
import { Observable, BehaviorSubject } from 'rxjs';
import { of } from 'rxjs';
import { UserService } from 'src/app/services/user.service';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss'],
  //encapsulation: ViewEncapsulation.None,
})
export class TestComponent implements OnInit {
  title = "La liste de mes offres d'emploi";
  url = environment.baseUrl;
  offres: any;
  currentUserSubject: BehaviorSubject<any>;
  currentSection: any;
  loading = false;
  public sectionSubject: Observable<any> = of([]);
  idUser: any;
  constructor(
    private router: Router,
    private offre: OffreService,
    private userServ: UserService) {
    this.sectionSubject = this.userServ.getUser();
    this.sectionSubject.subscribe((data: any) => {
      this.currentSection = data;
      console.log(data)
    });
    this.currentUserSubject = new BehaviorSubject<any>(localStorage.getItem('idUser'));
    if (this.currentUserSubject.getValue() !== null) {
      const a = JSON.parse(localStorage.getItem('idUser'));
      this.userServ.setUser(a);
      this.idUser = a;
    }
  }
  goTo(path) {
    this.router.navigateByUrl(path);
  }
  ngOnInit(): void {
    this.offre.getOfferByCreatorPublished(this.idUser).subscribe((res: any) => {
      this.offres = res.data;
      console.log(this.offres)
      this.loading = true;
    })
  }
}
