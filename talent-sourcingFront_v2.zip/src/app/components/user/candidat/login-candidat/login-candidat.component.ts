import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-candidat',
  templateUrl: './login-candidat.component.html',
  styleUrls: ['./login-candidat.component.scss']
})
export class LoginCandidatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
