import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-optiontester',
  templateUrl: './optiontester.component.html',
  styleUrls: ['./optiontester.component.scss']
})
export class OptiontesterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
